This file download from the CadNav

50000+ Free 3D Models & CAD  Models download��http://www.cadnav.com��

High quality 3D Models Library, online 3D Models resource for CGI graphic designers and CAD/CAM/CAE engineers, daily updates will be posted on our site. (http://www.cadnav.com/3d-models/)

You can download polygonal mesh 3D Models, 3D CAD Solid Object, Textures, Vray material, 3D works, CAD drawings,etc. 

All of them in our website are FREE download.

INFO:��Please read the following information, otherwise please don't use this model!

1. We doesn't accept any claims regarding quality of 3D model or any standards conformity.
2. We will not participate in any technology or copyright issues.
3. This file (models or textures) may be used in any commercial way only as a part of artwork or project. Single reselling or redistribution of this model is prohibited.  
4. This file (models or textures) may be freely modificated or elaborated.
5. If you use this file (models or textures) in your project or website, please indicate the source! 

Thank you for reading this file.

If you wanna rerelease the file in another website, please keep this info file included, thank you.  

ENJOY! 